#include <stdio.h>
int main(void) { 
    int x = 1; 
    int a; 
    a = ++x + ++x + ++x; 
    printf("a = %d", a);
    return 0;
}