/**
 *˵�������ǵ���εĵ�һ����ҵ�����������
 *����������ѩ
 *ѧ�ţ�2016011459
 *�༶��3��
 *���ڣ�2017/05/27
*/
#include<stdio.h>
int main(void)
{
    int n,i=0;
    char arr1[] = "abcdefghijklmnopqrstuvwxyz1234567890"; 
    char arr2[] = "18ac4y7bxuiep23hjs5ofwv0zdl9gkm6nqrt"; 
    char arr3[1000];
    scanf("%s",arr3);
    do
    {
        for(n=0;n<36;n++)
        {
            if(arr3[i]==arr1[n])
            {
                printf("%c",arr2[n]);
                break;
            }
        }
        i++;
    }while(arr3[i]!=0);


    return 0;
}
/*
#include <stdio.h>
#include <string.h>

int main(void)
{
    char arr1[] = "abcdefghijklmnopqrstuvwxyz1234567890";
    char arr2[] = "18ac4y7bxuiep23hjs5ofwv0zdl9gkm6nqrt";
    char str[100];
    int i, j, len;
    
    gets(str);
    for(i=0; i<strlen(str); i++)
    {
        for(j=0; j<strlen(arr1); j++)
        {
            if(str[i] == arr1[j])
            {
                str[i] = arr2[j];
                break;
            }
        }
    }

    puts(str);

    return 0;
}
*/
