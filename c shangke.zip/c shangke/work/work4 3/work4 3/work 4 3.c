/**
 *˵�������ǵ��Ĵεĵ�������ҵ���ϲ�����
 *����������ѩ
 *ѧ�ţ�2016011459
 *�༶��3��
 *���ڣ�2017/05/04
*/
#include<stdio.h>
int main(void)
{
    int arr1[4] = {3,6,9,11}; 
    int arr2[5] = {1,3,8,45,89};
    int arr3[9],arr4[9];
    int i,j,k,temp,a,index=1;
    k=0;
    for(i=0;i<4;i++)
    {
        arr3[i]=arr1[i];
    }
    for(j=0;j<5;j++)
    {
         arr3[i]=arr2[j];
        i++;
    }
    for(i=0;i<8;i++)
    {
        for(j=0;j<8-i;j++)
        {
            if (arr3[j]>arr3[j+1])
            {
                temp=arr3[j];
                arr3[j]=arr3[j+1];
                arr3[j+1]=temp;
            }
        }
    }
    for(k=0;k<9;k++)
    {
        if(arr3[k]== arr3[k+1])
            arr3[k] ;
    }
   
    arr3[9]=arr4[9];
     for(a=0;a<9;a++)
    {
        if(arr3[a] != arr3[a+1])
            arr4[index++]=arr3[a];     
    }
   
    for(index=1;index<9;index++)
    {
        printf("%d ",arr4[index]);
    }



    return 0;
}
/*


+#include <stdio.h>

int main(void)
{ 
    int arr1[4] = {3,6,9,11}; 
    int arr2[5] = {1,3,8,45,89};
    int arr3[9] = {0};
    int i=0, j=0, n=0;

    while(i<4 || j<5)
    {
        if(i==4)
            arr3[n++] = arr2[j++];
        else if(j==5)
            arr3[n++] = arr1[i++];
        else if(arr1[i] < arr2[j])
            arr3[n++] = arr1[i++];
        else if(arr1[i] > arr2[j])
            arr3[n++] = arr2[j++];
        else 
        {
            arr3[n++] = arr1[i++];
            j++;
        }
    }

    for(i=0; i<n; i++)
        printf("%d ", arr3[i]);
    printf("\n");
    
    return 0;
}
*/