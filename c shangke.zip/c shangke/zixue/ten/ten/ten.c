#include<stdio.h>
int main(void)
{
    int a,b;
    printf("\n");
    for(a=1;a<=9;a++)
    {
        for(b=1;b<=a;b++)
        {
            
            printf("%d*%d=%-3d",a,b,a*b);        
        }
        printf("\n");
    
    }

    return 0;
}