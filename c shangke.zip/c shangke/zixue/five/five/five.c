#include<stdio.h>
#include<math.h>
int main(void)
{
    int i,j;
    int num=0;
    for(i=2;i<=100;i++)
    {
        for(j=2;j<=100;j++)
        {
            if (i%j==0)
                break;
        }
        if (j>=i) 
        {
            printf("%3d\n",i);
            num +=1;
        }
    }
    printf("100�������������ĺ�Ϊ��%d\n",num);


    return 0;


}
