#include<stdio.h>
#include<stdlib.h>
int main(void)
{
    int a,b,c;
    double d;
    b=1234567890;
    c=123;
    d=3.1415926;
    scanf("��Ҫ��a��ֵ10",&a);
    printf("��Ҫ��a��ֵ%4d\n",a);
    printf("%3d\t%d\n",b,c);
    printf("%.2f",d);
    system("pause");


    return 0;
}