#include<stdio.h>
#include<stdlib.h>
 int fun(int n)
    {
        if(n==1)
            return 1;
        else
            return n*fun(n-1);
    
    }
int main (void)
{
    int n;
    for()
	printf("%d\n",fun(4));
}
