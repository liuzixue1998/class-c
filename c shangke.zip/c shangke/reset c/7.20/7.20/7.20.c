#include <stdio.h> 
void maxarr(int *p,int len)
{
    int i,temp=0,max=0,i1=0;
    for(i=0;i<len-1;i++)
    {
       if (p[i]>max)
       {
           max=p[i];
           i1 = i;
       }
    }
    temp = p[0]; 
    p[0] = p[i1];  
    p[i1] = temp;  

    for(i=0;i<len;i++)
        printf("%d ",*(p+i));
}
int main(void) 
{
   int  arr[8]={9,45,3,2,4,99,100,12};
   maxarr(arr,8);

    return 0; 
}