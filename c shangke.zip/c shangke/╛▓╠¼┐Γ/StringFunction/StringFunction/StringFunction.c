#include"StringFunction.h"

char *myStrcat(char *p, const char *q)
{
    while (*p)
        p++;
    while (*q)
        *p++ = *q++;

    return p;
}

int myStrlen(const char *p)
{
    int i = 0;
    while (p[i] != '\0')
        i++;
    return i;
}

int myStrcmp(const char *p, const char *q)
{
    int i;
    for (i = 0; p[i] == q[i]
        && p[i]; i++);
    return p[i] - q[i];
}

char myStrcpy(char *p, const char *q)
{
    int i;
    for (i = 0; q[i] != '\0'; i++)
        p[i] = q[i];
    p[i] = '\0';

    return *p;
}
