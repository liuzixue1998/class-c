char *myStrcat(char *p, const char *q);

int myStrlen(const char *p);

int myStrcmp(const char *p, const char *q);

char myStrcpy(char *p, const char *q);