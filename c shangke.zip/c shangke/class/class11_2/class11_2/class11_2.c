#include<stdio.h>
int main(void)
{
    //int arr[5][5];
    //int i,n,sum;
    //for(i=0;i<5;i++)//ÿһ��
    //{
    //    for(n=0;n<5;n++)//ÿһ��
    //    {
    //       scanf( "%d",&arr[i][n]);
    //    }
    //}
    //for(i=0;i<5;i++)
    //{
    //    for(n=0;n<5;n++)
    //    {
    //        if(i==0||i==4)
    //            sum+=arr[i][n];
    //        if(n==0||n==4)
    //            sum+=arr[i][n];
    //    }
    //}
    //sum-=arr[0][0];
    //sum-=arr[0][4];
    //sum-=arr[4][0];
    //sum-=arr[4][4];
    //printf("sum=%d\n",sum);


    //for(i=0;i<5;i++)
    //{
    //    for(n=0;n<5;n++)
    //    {
    //       if((i==n)||(i+n=4))
    //           sum+=arr[i][n];
    //    }
    //}
    //printf("�Խ���֮��%d",sum);

    ////�Խ��ߡ��±�i=n��i+n=4��

    //zָ��
    //int a=3;
    //int *p=&a;
    //*p=10;
    //printf("a=%d\n",a); //10
    //printf("*p=%d\n",*p);//10
    //printf("&a=%p\n",*p);
    //printf("*p=%p\n",*p);
    //printf("&p=%p\n",*p); //**p����ָ��

    /*int a=3;
    double *p=&a;
    printf("p=%p\n",p);
    printf("p+1=%p\n",p+1);
    printf("p-1=%p\n",p-1);*/

    /*double a[3]={1.0,2.0,3.0};
    double * p=&a[1];
    printf("*p=%.2lf\n",*p);
     printf("*p+1=%.2lf\n",*p+1);
   printf("*p-1=%.2lf\n",*p-1);*/
    /*double a[10]={1.0,2.0,3.0};
    double *p=&a[9];
    int i;
    for(i=0;i>=0;i--)
    {
        printf("%.2lf\n",*(p-i));
    }
*/
    int x = 3, y = 4, z; 
    int * p = &x, * q=&y; 
    printf("%d\n",y = *p + 5);
    printf("%d\n",y = *p * 6);
    printf("%d\n",z = *p + *q);



    return 0;
}