#include<stdio.h>
int main(void)
{
    /*int arr[5][3];
    int i,n;
    for(i=0;i<5;i++)
    {
        for(n=0;n<3;n++)
        {
            arr[i][n]=(i+1)*10+(n+1);
            printf("%d ",arr[i][n]);
        }
        printf("\n");
    }
    for(i=0;i<15;i++)
    {
        printf("%d ",arr[i/3][i%3]);
        if(i%3==2)
            printf("\n");
    }*/
    /*
     11 12 13
     21 22 23
     ...
    */
    int arr[6][2],ave[6];
    int i,n,sum;
    for(i=0;i<6;i++)
    {
        printf("�������%d��ͬѧ�ĳɼ�",i+1);
        printf("(c���ԣ���ԭ)");
            for(n=0;n<2;n++)
                scanf("%d",arr[i][n]);
    }
    for(i=0;i<6;i++)
    {
        for(n=0;n<2;n++)
        {
            sum+=arr[i][n];
        }
        ave[i]=(double)sum/2;
        printf("��%d��ͬѧƽ���ɼ�%��2lf\n",i+1,ave[i]);
    }
    for(i=0;i<2;i++)
    {
        sum=0;
        for(n=0;n<6;n++)
            sum+=arr[n][i];

    }
    return 0;
}