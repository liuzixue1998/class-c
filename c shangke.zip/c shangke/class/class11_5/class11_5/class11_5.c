#include<stdio.h>
int main(void)
{
    //int a=10;
    //int * p=&a;
    //int **q=&p;//����ָ��
    //printf("a=%d\n",a);
    //printf("*p=%d\n",*p);
    //printf("**q=%d\n",**q);

    //printf("p=%p\n",p);//%p=point
    //printf("*q=%p\n",*q);
    //printf("&a=%p\n",&a);

    //printf("q=%p\n",q);
    //printf("&p=%p\n",&p);
    ////p==&q q==&a
    //printf("");

    //int a=10;
    //int *q;//Ұָ��
    //int*p=NULL;//NULL��ȫ��0 ��ָ��
    //if(p)//(p!=NULL)
    //printf("%d\n",*p);


    int a[5] = {11, 12, 13, 14, 15}; 
    int *p=a;
    int i;
   /* printf("&a[0]   = %p\n", &a[0]); 
    printf("&a[0]+1 = %p\n", &a[0] + 1);
    printf("a   = %p\n", a); 
    printf("a+1 = %p\n", a + 1);
    printf("&a   = %p\n", &a); 
     printf("&a+1 = %p\n", &a + 1); */
    for(i=0;i<5;i++)
        printf("%d ",a[i]);
    printf("\n");

    for(i=0;i<5;i++)
        printf("%d ",*(a+i));
    printf("\n");

    for(i=0;i<5;i++)
        printf("%d ",p[i]);
    printf("\n");

    for(i=0;i<5;i++)
        printf("%d ",i[a]);
    printf("\n");

    //a[1]=>*(a+1)
    //1[a]=>*(1+a)
    //*(p+1)<=p[1]
    //a==&a[0]
    //p==&a[0]
    //&a������a�ĵ�ַ  &a+1 ���ƶ�һ�����鵥λ
    //&p��ָ�����p�ĵ�ַ  &p+1���ƶ�һ��ָ�뵥λ


    return 0;
}