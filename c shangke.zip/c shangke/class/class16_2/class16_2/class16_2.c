#include<stdio.h>
#include<malloc.h>
#include<stdlib.h>

int mymax(int a,int b)
{
    return a>b?a:b;
}
int mysum(int a,int b)
{
    
}
int main(void)
{
   /* int num,i;
    int *p;
    scanf("%d",&num);
    p=(int*)malloc(num * sizeof(int));
    for(i=0;i<num;i++)
    {
        printf("�������%d��ѧ���ĳɼ�",i+1);
        scanf("%d",p+i);
    
    }
    for(i=0;i<num;i++)
        printf("%d",*(p+i));

    puts("");
    free(p);

    int *a=(int *)calloc(3,4);
    int *q=(int *)calloc(1,4);

    printf("*p=%d\n",*a);
    printf("*q=%d\n",*q);*/


    /*int num=0;
    while(1)
    {
        if(malloc(10000000))
            num++;
        else
        {
            printf("������ɹ�%d��",num);
            system("pause");
        }
    
    }*/

    /*int (*p)(int a,int b)=mymax;
    printf("p=%p\n",p);
    printf("%p\n",mymax);

    printf("%d\n",mymax(10,20));*/

    


    return 0;
}