#include<stdio.h>
int main(void)
{
    //��������
    /*int i,temp;
    int a[10]={1,2,3,4,5,6,7,8,9,10};
    for(i=0;i<5;i++)
    {
        temp =a[i];
        a[i]=a[9-i];
        a[9-i]=temp;
    }
    for(i=0;i<10;i++)
        printf("%d",a[i]);*/
    


    int n,temp,i;//��С����洢 ð��
    int a[10]={11,44,22,33,99,55,77,66,88,0};
    for(i=0;i<9;i++)
    {
    for(n=0;n<9;n++)
    {
      if(a[n]>a[n+1])
      {
           temp =a[n];
           a[n]=a[n+1];
           a[n+1]=temp;    
      }
    }
    }
    for(n=0;n<10;n++)
        printf("%d  ",a[n]);
  return 0;
}
