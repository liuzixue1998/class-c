#include<stdio.h>
int main(void)
{
   /* char arr[]="hello world!";
    int len=0;
   // printf("%s\n",arr);
    char *p=arr;//&arr[0]//���ж���ѭ��
    while(*p!='\0') 
    {
    printf("%c",*p);
    p++;
    }
    while(*(arr+len++));//--len;
    printf("len=%d\n",len);
    //while(*p)
    //printf("%c",*p++);*/
    char s1[]="wuyanzu";
    char s2[100];
    int i;
    for(i=0;;i++)
        s2[i]=s1[i];
    /*gets(s);
    puts(s);
*/

    return 0;
}