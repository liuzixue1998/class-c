#include<stdio.h>
int main(void)
{
    int a=51,b=101;
    a=a^b;
    b=a^b;
    a=a^b;
    printf("a=%d\nb=%d\n",a,b);
    //������ֵ

    return 0;
}
