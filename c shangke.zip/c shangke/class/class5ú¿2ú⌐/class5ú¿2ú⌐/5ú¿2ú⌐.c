#include<stdio.h>
int main (void)
{
    int i=1;
    //printf("%d\n",i++ + ++i);//δ����Ľ��//4
 /* i =1;
    printf("%d\n",i++ + ++i +i);*/


    printf("%d\n",i++*3);
    printf("%d\n",i);
    printf("%d\n",++i);
    printf("%d\n",i);  
    return 0;



}