#include<stdio.h>
int main(void)
{
    int a=10;
    printf("%.2lf\n",a/3);// 0.00 int���ĸ��ֽ�
    printf("%.2lf\n",a/3*1.0);
    printf("%.2lf\n",a/(3*1.0)); //3���double����
    printf("%.2lf\n",(1.0*3)/3);
    printf("%.2lf\n",(double)(a/3));//3.00
    printf("%.2lf\n",(double)a/3);//3.33
    //�����˭����ת��
    int x=0x89898;
    short y;
    y=x;


/*
    double <= float
       |^
    unsigned long
      |^
    long
      |^
    unsigned int
      |^
    //int <= char short

    char    short    int    long    long long
*/
    return 0;
}