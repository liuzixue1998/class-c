#include<stdio.h>
int main(void)
{
    ////��ѭ����Բ������ܳ�
    // double  r,a,c;
    //const double pi =3.14159;
    //char flag;
    //do
    //{
    //     printf("������뾶:");
    //     scanf("%lf",&r);
    //
    //if (r<=0)
    //{
    //    printf("��������Ƿ�");
    //}
    //else
    //{
    //    a=pi*r*r;
    //    c=pi*2*r;
    //    printf("������:%.2lf \n",a);
    //    printf("����ܳ�:%.2lf\n",c);
    //
    //}
    //printf("�Ƿ�������㣿��Y/N����");
    ////getchar()
    ////fflush(stdin); //stdout ��������
    //scanf("%c",&flag);
    //scanf("%c",&flag);
    //}while(flag=='Y' || flag =='y');

    //ˮ�ɻ���  abc=a^3+b^3+c^3
   // int i,j,k,n;
   // printf("ˮ�ɻ���:\n");
   // for (n=100; n<1000; n++) 
   // {
   // i=n/100;
   // j=(n-i*100)/10;
   // k=n%10;
   // if(i*i*i+j*j*j+k*k*k==n)
   // {
   // printf("%d ",n);
   // }
   //}
 /*   int i=1;
    for(i=1;i<100;i++)
    {
        if(i%2==1)
            continue;
        printf("%d\n",i);
    }
*/
    int a,b,c,min,i;
    //min =a<b?a:b;
    //min=min<c?min:c;
    //for (i=min;i>=1;i--)
 /*   {
        if(a%i==0 && b%i==0 &&c %i==0)
        {
            printf("%d\n",i);
            break;
        }
    
    }*/
    min=a;
    if(min>b)
    {
        min=b;
    }
    if(min>c)
    {
        min=c;
    }
       for(i=1;i<=min;i++)   
    {
        if(a%i==0 && b%i==0 && c%i==0)  
        {
          printf("���Լ��Ϊ%d",i);
          break;
        }
         
    }
    return 0;
}