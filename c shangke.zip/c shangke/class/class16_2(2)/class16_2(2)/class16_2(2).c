/* strlen   �ַ�������
        strcpy   �ַ�������
        strcat   �ַ���ƴ��
        strcmp   �ַ����Ƚ�
    */
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int mystrlen (char * str)
{
   /* int i=0;
    while(str[i]!=0)
        i++;
    return i;*/
    int i;
    for(i=0;*(str+i)!='\0';i++)
       return i ;

}
char *mystrcpy(char *p1,const char *p2)
{
    int i;
    for(i=0;p2[i]!='\0';i++)
        p1[i]=p2[i];
    p1[i]='\0';
    return p1;
}
char mystrcat(char *p3,const char * p4)
{
    int i,j;
    for(i=0;p3[i]!='\0';i++);
    for(j=0;p4[j]!='\0';j++)
        p3[i+j]=p4[j];
    p3[i+j]='\0';
    return p3;
}
int mystrcmp(char const *p1,const char *p2)
{
    int i=0;
    for(i=0;(p1[i]==p2[i])&&
        (p1[i]!='\0')&&
        (p2[i]!='\0');i++)
        ;
    return p1[i] -p2[i];

}
int main(void)
{
    char arr[100]="liangchaowei";
    printf("%d\n",mystrlen("liudehua"));
    printf("%d\n",mystrlen(arr));

    char arr[100];
    puts(mystrcpy(arr,"wuyanzu"));

    char arr[100]="hello";
    puts( mystrcat (arr,"world"));
    char arr[100]="abcd";
     printf("%d\n",mystrcmp("abcd","abcc"));

    printf("%d\n",mystrcmp("abcd",arr));
    



    return 0;
}